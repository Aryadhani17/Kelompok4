<footer class="sticky-footer bg-white">
	<div class="container my-auto">
		<div class="copyright text-center my-auto">
			<span>Copyright © <a href="https://instagram.com/ya_aryaa" target="_blank">Aryadhani Faturrahman</a></span>
		</div>
	</div>
</footer>